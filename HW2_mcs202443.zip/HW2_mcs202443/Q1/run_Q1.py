import sys
from matplotlib import pyplot as plt
import datetime
import subprocess
import math

def processNodes(nodes,nodeLabel,lines):
    global index
    #print('3:'+str(index))
    numNodes = int(lines[index].rstrip());
    index = index + 1
    #print('4:'+str(index))
    for i in range(0,numNodes):
        #print(lines[index].rsplit()[0],end=" -> ")

        if nodeLabel.get(lines[index].rsplit()[0]) == None:
            nodeLabel[lines[index].rsplit()[0]] = len(nodeLabel)
        nodes[i] = nodeLabel[lines[index].rsplit()[0]]
        #print(nodes[i])
          
        index = index + 1
        
    return numNodes
 
    
    
    
    
def processEdges(edges,lines):
    global index
    #print('5:'+str(index))
    numEdges = int(lines[index].rstrip());
    for i in range(1,numEdges+1):
        edge = list(map(lambda x : int(x) , lines[index+i].rstrip().split(' ')))
        #print(edge)
       
        #now edge[sourceNode destNode edgeLabel]
        
        edges.append(edge)
    
    index = index + numEdges + 1
    return numEdges





def readDb(input_file):
    global index;
    lines = None
    with open(input_file) as f:
        lines = f.readlines()
        
    n = len(lines);

    graphDb = []

    index = 0;
    nodeLabel = {};
    while (index < n):
        newGraph = { }
        #print('1:'+str(index))
        graphId = lines[index].rstrip().split('#')[1]
        newGraph['graphID'] = graphId
        nodes = {};
        edges = [];


        index = index + 1
        #print('2:'+str(index))
        newGraph['numNodes'] = processNodes(nodes,nodeLabel,lines)
        newGraph['numEdges'] = processEdges(edges,lines)
        newGraph['nodes'] = nodes;
        newGraph['edges'] = edges;
        graphDb.append(newGraph);
        index = index + 1
        #print()
        #if(len(graphDb) == 2):
        #    break  
    return graphDb     





def outputGraph(graphDb,fileName,c):
    outLines = []
    for graph in graphDb:
        outLines.append('t # '+graph['graphID']+'\n')
        for i in range(graph['numNodes']):
            outLines.append('v '+str(i)+' '+str(graph['nodes'][i])+'\n')
        for j in range(graph['numEdges']):
            edge = graph['edges'][j]
            outLines.append(c+' '+str(edge[0])+' '+str(edge[1])+' '+str(edge[2])+'\n')
    
    output_file_name = fileName+c+'.txt'
    with open(output_file_name, 'w') as f:
        f.writelines(outLines)
    return output_file_name     
    
    






        
    


# In[62]:


def compute_time(numGraphs,support_list, input_file_gspan_gaston,input_file_fsg):
    gspan_times = []
    fsg_times = []
    gaston_times = []
    inf = 999999999
    for support in support_list:
        print('For Support: ',support)
       
        output = None
        try:
            
            curSupport = support / 100;
            print("curSupport for gSpan: "+str(curSupport));
            t1= datetime.datetime.now()
            output = subprocess.run(['./Q1/gSpan','-f',input_file_gspan_gaston,'-s',str(curSupport),'-o','-i'] )
            t2 = datetime.datetime.now()
            gSpanTime = t2 - t1  
        except subprocess.TimeoutExpired:
            print("Timeout/Error executing gSPan Algo for Support = ", support)
            gSpanTime = inf
       
        print('gSPan Time :',gSpanTime)
        try:
            curSupport = support
            print("curSupport for fsg: "+str(curSupport));
            t1= datetime.datetime.now()
            output = subprocess.run(['./Q1/fsg','-s', str(curSupport), input_file_fsg])
            t2 = datetime.datetime.now()
            fsgTime = t2 - t1 
        except subprocess.TimeoutExpired:
            print("Timeout/Error executing fsg Algo for Support = ", support)
            fsgTime = inf
        #print(output.stdout)
        print('fsg Time: ',fsgTime)
        try:
            curSupport =  math.ceil((numGraphs * support) / 100);
            print("curSupport for gaston: "+str(curSupport));
            t1= datetime.datetime.now()
            output = subprocess.run(['./Q1/gaston', str(curSupport), input_file_gspan_gaston])
            t2= datetime.datetime.now()
            gastonTime = t2 - t1
            
        except subprocess.TimeoutExpired:
            print("Timeout/Error executing gaston Algo for Support = ", support)
            fsgTime = inf
        print('gaston Time: ',gastonTime)
        gspan_times.append((gSpanTime).total_seconds())
        fsg_times.append((fsgTime).total_seconds())
        gaston_times.append((gastonTime).total_seconds())
        
    return gspan_times, fsg_times,gaston_times
    
    


# In[ ]:


def plot_runtime(support_list, gspan_times, fsg_times,gaston_times,plot_name):
    plt.plot(support_list, gspan_times,'r', label = 'Gspan')
    plt.plot(support_list, fsg_times,'g', label = 'Fsg')
    plt.plot(support_list, gaston_times,'b', label = 'Gaston')
    plt.xlabel('Support %')
    plt.ylabel('Run Time (sec)')
    plt.legend()
    plt.savefig(plot_name+'.png')
    print('Plot saved on'+plot_name+'.png')


# In[ ]:

#'./167.txt_graph'
#'Running_time_plot'

raw_input_file_name = sys.argv[1]
plot_file_name = sys.argv[2]
graphDb = readDb(raw_input_file_name)
output_file_name_gpsan_gaston = outputGraph(graphDb,'graph_output_','e')
output_file_name_fsg = outputGraph(graphDb,'graph_output_','u')
numGraphs = len(graphDb)
support_list = [5.0,10.0,25.0,50.0,95.0]
gspan_times,fsg_times,gaston_times =  compute_time(numGraphs,support_list,output_file_name_gpsan_gaston,output_file_name_fsg)
plot_runtime(support_list,gspan_times,fsg_times,gaston_times,plot_file_name)




