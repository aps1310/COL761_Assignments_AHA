#!/bin/sh
### Set the job name (for your reference)

#PBS -q low
#PBS -N test_run_all_second
### Set the project name, your department code by default
#PBS -P cse
### Request email when job begins and ends, don't change anything on the below line
#PBS -m bea
### Specify email address to use for notification, don't change anything on the below line
#PBS -M $USER@iitd.ac.in
#### Request your resources, just change the numbers
#PBS -l select=1:ncpus=4:ngpus=0:mem=32G
### Specify "wallclock time" required for this job, hhh:mm:ss
#PBS -l walltime=06:00:00
#PBS -l software=gcc

# After job starts, must goto working directory.
# $PBS_O_WORKDIR is the directory from where the job is fired.
echo "==============================="
echo $PBS_JOBID
cat $PBS_NODEFILE
echo "==============================="
cd $PBS_O_WORKDIR
echo $PBS_O_WORKDIR

module () {
        eval `/usr/share/Modules/$MODULE_VERSION/bin/modulecmd bash $*`
}

module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
module load compiler/gcc/7.1.0/compilervars
module load compiler/python/3.6.0/ucs4/gnu/447
module load apps/anaconda/3
#module load apps/anaconda/3EnvCreation

# for pretrain change pbs filename,boolean arg is true(1), and last but one arg is previous epoch number - 1 

# First argument is the path of the model and second argument is the path of the training data


#bash Q1.sh ./Q1/167.txt_graph Running_time_plot

bash Q1_second.sh /home/cse/mtech/mcs202448/col761AssignmentDir/Assignment_2_folder_final/Q1/167.txt_graph /home/cse/mtech/mcs202448/col761AssignmentDir/Assignment_2_folder_final/Running_time_plot
