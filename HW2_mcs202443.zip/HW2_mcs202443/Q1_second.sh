#!/bin/sh



chmod u+x ./Q1/gSpan
chmod u+x ./Q1/gaston
chmod u+x ./Q1/fsg


echo "Running Q1.sh script cDir : ${PWD} "


echo "first Parameter : ${1} "

echo "second Parameter : ${2}"

python3 ./Q1/run_Q1_second.py $1 $2
