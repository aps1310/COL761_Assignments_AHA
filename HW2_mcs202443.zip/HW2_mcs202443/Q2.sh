#!/bin/sh
echo "Current : ${PWD}"
echo "First : ${1}"
echo "Second : ${2}"
python3 ./Q2/perform_pca.py $1 2
python3 ./Q2/perform_pca.py $1 4
python3 ./Q2/perform_pca.py $1 10
python3 ./Q2/perform_pca.py $1 20
python3 ./Q2/kd_tree.py 
python3 ./Q2/seq.py 
python3 ./Q2/mtree/run_script.py 
python3 ./Q2/plot_err.py $2 
