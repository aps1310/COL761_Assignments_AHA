import numpy as np
import datetime
from sklearn.neighbors import KDTree

wr = open('kd_time.txt', 'w')
filenames = ['pca_2.dat', 'pca_4.dat', 'pca_10.dat', 'pca_20.dat']
for filename in filenames:
    f = open(filename)
    # load file
    pts = np.loadtxt(f, delimiter=" ")
    # number of elements
    n = np.size(pts, 0)

    # sample 100 points
    idx = np.random.randint(n, size=100)

    # create tree
    tree = KDTree(pts)

    T = []
    # check for query
    for q in idx:
        s = datetime.datetime.now()
        dist, ind = tree.query([pts[q]], k=5)
        # print("Distance:", dist)
        # print("Indices:", ind)
        T.append((datetime.datetime.now() - s).total_seconds())
    T = np.array(T)
    wr.write(str(np.mean(T)) + ' ' + str(np.std(T)) + '\n')

wr.close()
