import sys
import matplotlib.pyplot as plt

filename = sys.argv[1] + '.png'

def read_file(f):
    f = open(f)
    x = []
    y = []
    for l in f:
        a,b = list(map(float, l.strip().split()))
        x.append(a)
        y.append(b)
    return x,y

# read files
x = [2,4,10,20]
y,e = read_file('kd_time.txt')
a1 = plt.errorbar(x,y,e,linestyle=None,marker='^',capsize=3)
y,e = read_file('seq_time.txt')
a2 = plt.errorbar(x,y,e,linestyle=None,marker='^',capsize=3)
y,e = read_file('m_time.txt')
a3 = plt.errorbar(x,y,e,linestyle=None,marker='^',capsize=3)
plt.xlabel('Dimension')
plt.ylabel('Time(seconds)')
plt.legend([a1,a2,a3],['KDTree','Sequential','M-tree'])
# plt.show()
plt.savefig(filename)
