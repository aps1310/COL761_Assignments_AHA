import sys
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

if len(sys.argv) != 3:
    print("Provide both filename and number of components")
    exit()

filename = sys.argv[1]
n = int(sys.argv[2])

# load dataframe
df = pd.read_csv(filename,header=None, delim_whitespace=True)

scaling = StandardScaler()
scaling.fit(df)
scaled_data = scaling.transform(df)

principal=PCA(n_components=n)
principal.fit(scaled_data)
x=principal.transform(scaled_data)

# print(pd.DataFrame(x).head())
pd.DataFrame(x).to_csv('pca_'+ str(n) + '.dat', sep=" ", index=False, header=False)
