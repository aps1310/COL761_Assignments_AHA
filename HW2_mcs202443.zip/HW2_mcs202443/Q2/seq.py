import numpy as np
import datetime
import heapq


def seq_find(n, pts, Q, k):
    # create a list finding the
    # distance between pts and Q and index
    lst = []
    for i in range(n):
        # if i%1000 == 0:
            # print(i)
        lst.append((np.linalg.norm(pts[i]-Q), i))
    # heapify to create minheap
    heapq.heapify(lst)
    # find top k elements and return
    res = []
    for i in range(k):
        # pop top smallest element
        s = heapq.heappop(lst)
        res.append(s)
    
wr = open('seq_time.txt', 'w')
filenames = ['pca_2.dat', 'pca_4.dat', 'pca_10.dat', 'pca_20.dat']
for filename in filenames:
    f = open(filename)
    # load file
    pts = np.loadtxt(f, delimiter=" ")
    # number of elements
    n = np.size(pts, 0)

    # sample 100 points
    idx = np.random.randint(n, size=100)


    T = []
    # check for query
    for q in idx:
        s = datetime.datetime.now()
        seq_find(n, pts, pts[q], k=5)
        # print("Distance:", dist)
        # print("Indices:", ind)
        T.append((datetime.datetime.now() - s).total_seconds())
    T = np.array(T)
    wr.write(str(np.mean(T)) + ' ' + str(np.std(T)) + '\n')

wr.close()
