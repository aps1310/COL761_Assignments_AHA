
import numpy
import math

class DistanceFunction(object):
    def __init__(self):
        pass

    def distance_function_numpy(self,x,y):
        return numpy.linalg.norm(x-y);

    def distance_function_point(self,x,y):
        sum = 0.0;
        if (len(x) != len(y)):
            print("Error : Difference in Dimension, dimension(x):" + str(len(x)) + " dimension(y):" + str(len(y)));
            exit(0);
        for i in range(len(x)):
            sum = sum + pow((x[i] - y[i]), 2);
        return math.sqrt(sum)


class DB(object):


    def __init__(self, input_file):

        with open(input_file) as f:
            lines = f.readlines()

        self.dimension = len(lines[0].rstrip().split(' '))
        self.size = 0
        self.db = []
        for i in range(len(lines)):
            #if(self.size == 10):
            #    break;
            point = lines[i].rstrip().split(' ')
            if len(point) != self.dimension:
                print("Required Dimension: " + str(self.dimension) + " Wrong Dimension point: " + point);
                exit(0);
            point = list(map(lambda x: float(x), point));
            self.db.append(point)
            self.size = self.size + 1;
        print("Read Input Success ,Dimension: " + str(self.dimension) + ", Number of Points: " + str(self.size));
        f.close()
    def __getitem__(self, key):
        return self.db[key];

    def __len__(self):
        return self.size

def distance_function_point(x,y):
    sum = 0.0;
    if(len(x) != len(y)):
        print("Error : Difference in Dimension, dimension(x):"+str(len(x))+" dimension(y):"+str(len(y)));
        exit(0);
    for i in range(len(x)):
        sum = sum + pow((x[i] - y[i]),2);
    return math.sqrt(sum)








