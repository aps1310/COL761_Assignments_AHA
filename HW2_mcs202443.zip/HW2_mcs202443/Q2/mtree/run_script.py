import sys
from input import DB ,DistanceFunction
from mtree import MTree
import numpy as np
import datetime

filenames = ['pca_2.dat', 'pca_4.dat', 'pca_10.dat', 'pca_20.dat']
wr = open('m_time.txt', 'w')
# filenames = ['../pca_4.dat']
for filename in filenames:
    database = DB(filename)
    df = DistanceFunction()
    tree = MTree(df.distance_function_point, max_node_size=20)
    tree.add_all(database.db);
    print('MTree created')

    n = len(database)

    idx = np.random.randint(n, size=100)

    T = []
    # check for query
    for q in idx:
        s = datetime.datetime.now()
        res = tree.search(database[q],5)
        # print("Distance:", dist)
        # print("Indices:", ind)
        T.append((datetime.datetime.now() - s).total_seconds())
    T = np.array(T)
    wr.write(str(np.mean(T)) + ' ' + str(np.std(T)) + '\n')
wr.close()    

'''
tree = MTree(distance_function, max_node_size=20)
tree.add(1)
tree.add_all([5,9,6,7,8,2,3,4,11,23,24,25,26,27,28,29,30,56,76,34,35,36,37,38,656,768,456,321,567,21,19,18,33])
print("Search 24 "+str(tree.search(35)))

print("Search 24  top-k/knn: 5 "+str(tree.search(35,5)));
'''


