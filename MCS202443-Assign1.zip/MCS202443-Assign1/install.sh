#!/bin/sh

git clone https://github.com/aps1310/COL761_Assignments_AHA.git

module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu
module load compiler/gcc/7.1.0/compilervars
module load compiler/python/3.6.0/ucs4/gnu/447
module load compiler/java/8.112/precompiled
