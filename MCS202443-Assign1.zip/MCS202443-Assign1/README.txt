Group Details -->
Team Members
  Name             Entry Number
Adish Jain          MCS202443
Akshay Sarashetti   MCS202448
Harsh Pandey        CSY217545

Files for Q1. Apriori Algorithm -->

  Implementation
  1) Language used : C++
  2) abc1.cpp : File containing the source code
    a) Reads the data file again and again to create next itemsets
    b) Writes the items to output file as soon as they are created.
    c) Vector of Vectors is used to store itemsets of same length.
  3) ap : Object file generated after compilation
  4) Uses : ./ap X output_file input_data_file
  5) Generates an output_file.txt containing output itemsets with support >= X% in ASCII order.

Files for Q2. Performance Comparison -->

  1) Fpgrowth directory has the fp-tree implementation
  2) CompareFpAp.py File Handles the execution of Apriori and Fp-Tree implementations
      for different values of support([90, 50, 25, 10, 5]) and plots a graph based on the same.
  3) To Run Comparison script (CompareFpAp.py) use command
    $ ./MCS202443.sh webdocs.dat -plot
  4) There is timeout added for 1hr if Apriori or Fp-Tree algorithm fails to execute within the time
      limit for a particular value of Support
  5) The result is plotted and saved on Running_time_plot.png

Files for Q3 Prefix Span implementation -->

  1) src Directory contains the code for prefixspan implementation in Main.java file.
  2) Pre-Processing Steps
    *) For every row in path_finished.tsv we read path column data
    *) data which was ';' separated was changed to ' ' separated
    *) if data had a (<) black click it was changed to respective logical page title as discussed.
    *) Later , only path data was stored in a separate file, such that if consider each row's path as a
        transaction each transaction was stored in a separate line of the file.
    *) The logic is there in the prefixspan_preprocessing_script.py script
  3) In the output file each frequent sub-sequence is printed in a separate line.
  4) If you give the output file_name it will be saved as file_name.txt
  5) Yes ,the output file contains an extra empty line after printing the last itemset/sub-sequence.
  6) The pre-processed data is stored in data/ folder as path_finished.dat

Other Files to Run -->

  1) The compile.sh file is required to compile the code and generate the required binaries.
  2) The MCS202443.sh file has code to run all the required programs
      a) ./RollNo.sh -apriori webdocs.dat X <filename> for Q1 (Apriori code and generate output)
      b) ./RollNo.sh webdocs.dat -plot for Q2 (Comparison code and plotting the graph)
      c) ./RollNo.sh -prefixspan paths_finished.dat X <filename> for Q3 (Prefixspan code and generate output)

Q2 Part b Explanation -->

  1) On running the code for Q2 we observe the already expected results, FP-Tree performed a lot better
    especially for lower support values in comparison with Apriori algorithm.
  2) The Main reason is because FP-Tree only requires 2 pass through the database but Apriori requires
    multiple pass for every candidate generation which increases it's complexity.
  3) Apriori algorithm follows the Breadth First Approach whereas FP-Tree follows Depth First Approach which
    turns out to be more efficient because the depth decreases as we proceed.
  4) The results are visible on the plot Running_time_plot.png provided in this repository.

Prefix Scan Verdict -->

  1) Prefix scan was generated for the given database and it was running successfully. It was tested on 15%, 10%, 5%, 3%, 2%, 1%, 0.5%
  2) Execution Completed within 5 mins
