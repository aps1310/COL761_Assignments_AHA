#!/bin/sh
echo 'Running MCS202443.sh script'
if [ $1 == '-apriori' ]
then
	./ap $3 $4 $2
elif [ $2 == '-plot' ]; then
	echo "Running Comparison"
	python3 CompareFpAp.py $1
elif [ $1 == '-prefixspan' ]; then
	echo "To be loaded prefixspan"
	java -classpath ./src Main $2 $3 $4
else
	echo "Invalid Parameters passed"
fi
