import numpy as np 
import pandas as pd 


df = pd.read_csv("../input/paths_finished.tsv",sep='\t',comment='#',names=['hashedIpAddress','timestamp','duratiionInSecs','path','rating'])

#df[df['path'].str.contains("<")]

df_new = df.copy()

'''
def process_path(path):
    str_list = path.split(';')
    previous1 = ""
    previous2 = ""
    previous = {}
    result_list = []
    for s in str_list:
       if s=='<':
        result_list.append(previous2);
        temp = previous2;
        previous2 = previous1;
        previous1 = temp; 
       else:
        result_list.append(s)
        previous2 = previous1;
        previous1 = s;
    return (';'.join(result_list))

'''
def process_path(path):
    str_list = path.split(';')
    previousDict = {}
    previous = ""
    result_list = []
    for s in str_list:
       if s=='<':
        result_list.append(previousDict[previous]);
        previous = previousDict[previous]
       else:
        result_list.append(s)
        previousDict[s] = previous; 
        previous = s;
        
    return (' '.join(result_list))



for i, row in df_new.iterrows():
    if '<' in row['path']:
        df_new.at[i,'path'] = process_path(row['path'])
    else:
        str_list = row['path'].split(';')
        df_new.at[i,'path'] = (' '.join(str_list))
        continue


print(process_path('a;b;c;<;<;d')   , process_path('a;b;c;<;d;<;<') , process_path('a;b;c;<;d;<;a;e;<;d;b;<'))



#df_new[df_new['path'].str.contains("<")]

df_col = df_new['path']


df_col.to_csv('./path_finished_6.dat', header=None,index=None , sep='\n', mode='a')


