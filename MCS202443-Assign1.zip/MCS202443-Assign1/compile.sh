#!/bin/sh
echo 'Runngin compile script'
g++ -O3 -o ap abc1.cpp
make -C fpgrowth/fpgrowth/src
javac ./src/Main.java
