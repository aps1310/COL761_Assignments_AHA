
import java.util.*;
import java.io.*;

public class Main {

    static TreeMap<String,List<String[]>> map;
    static List<List<String>> sequences;
    static List<Integer> seqSup;
    static int transactionCount;
    private static List<String> filterKeys(Set<String> set , int supThreshold)
    {
        List<String> validKeys = new LinkedList<>();


        for(String key : set)
        {
           // double supportPercent =  (((double)map.get(key).size()/transactionCount)*100.0);

            if(map.get(key).size() >= supThreshold)
            {
                sequences.add(Arrays.asList(key.split(";")));
                seqSup.add(map.get(key).size());
                validKeys.add(key);
            }
            else
            {
                map.remove(key);
            }

        }

        return validKeys;
    }

    private static void recursiveProjectedDB(String key,int supThreshold)
    {
        List<String[]> pdB = map.get(key);

        Set<String> newKeysSet = new TreeSet<>();

        //Only first occurence of key
        HashSet<String> keyFromSameTransactionCheck =new HashSet<String>();

        for(String[] strArr: pdB)
        {

            keyFromSameTransactionCheck.clear();

            int n = strArr.length;
            for(int i = 0 ; i < n ; i++)
            {

                if(strArr[i].equals(""))
                    break;



                String newKey = key+";"+strArr[i];

                if(keyFromSameTransactionCheck.contains(newKey))
                    continue;

                if (!map.containsKey(newKey))
                {
                    map.put(newKey, new LinkedList<>());
                    newKeysSet.add(newKey);
                }

                if(i==n-1)
                    map.get(newKey).add(new String[]{""});
                else
                    map.get(newKey).add(Arrays.copyOfRange(strArr,i+1,n));

                keyFromSameTransactionCheck.add(newKey);
            }
        }

        List<String> validKeys = filterKeys(newKeysSet,supThreshold);

        for(String validKey : validKeys)
        {
            recursiveProjectedDB(validKey,supThreshold);
            map.remove(validKey);
        }

    }
    private static void processTransaction(String transaction)
    {
        String[] arr = transaction.split(" ");

        //Only first occurence of key
        HashSet<String> keyFromSameTransactionCheck =new HashSet<String>();

        int n = arr.length;

        for(int i=0 ; i < n ; i++)
        {
            if(keyFromSameTransactionCheck.contains(arr[i]))
                continue;

            if (!map.containsKey(arr[i]))
                map.put(arr[i],new LinkedList<>());

           if(i==n-1)
              map.get(arr[i]).add(new String[]{""});
           else
           map.get(arr[i]).add(Arrays.copyOfRange(arr,i+1,n));

           keyFromSameTransactionCheck.add(arr[i]);
        }

    }
    private static void readFile(String filePath,double minSup)
    {
        File file = new File(filePath);

       try {
           Scanner sc = new Scanner(file);

           int count = 0;

           map = new TreeMap<>();

           sequences = new LinkedList<>();
           seqSup = new LinkedList<>();

           while (sc.hasNextLine()) {
               processTransaction(sc.nextLine());
               count++;
           }

           System.out.println("Transactions Count : " + count);

           transactionCount = count;

           int supThreshold = (int) Math.ceil(transactionCount * 0.01 * minSup);

           List<String> validKeys = filterKeys(new LinkedHashSet<>(map.keySet()),supThreshold);

           for(String validKey : validKeys)
           {
               recursiveProjectedDB(validKey,supThreshold);
               map.remove(validKey);
           }



       }catch(FileNotFoundException e)
       {
           System.out.println(e);
       }
    }

    private static void writeFile(String filePath)
    {
        File file = new File(filePath);
        try {

        if (file.createNewFile()) {
            System.out.println("File created: " + file.getName());
        } else {
            System.out.println("File already exists.");
        }

        FileWriter myWriter = new FileWriter(filePath);

        int n = sequences.size();

        for(int i=0;i<n;i++)
            {
                //myWriter.write("Pattern: [ " +String.join(" ",sequences.get(i))+" ] Support : "+seqSup.get(i)+" \n");
                myWriter.write(String.join(" ",sequences.get(i))+" \n");
            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args)
    {

       // System.out.println("len: "+args.length);
       if(args.length==0)
       {
           System.out.println("Enter file path");
           return;
       }

      Scanner sc =  new Scanner(System.in);
     // System.out.println("Enter the Min Support % : \n");
     // double minSup = Double.parseDouble(sc.nextLine());
        double minSup = Double.parseDouble(args[1]);

        System.out.println(" Min Support % : "+minSup);

      System.out.println("File : "+args[0]);
      readFile(args[0],minSup);
      System.out.println("Success  No. of Seq: "+sequences.size()+" seqSup: "+seqSup.size());
      writeFile(args[2]+".txt");
    }
}
